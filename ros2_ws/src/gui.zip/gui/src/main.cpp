#include <QApplication>
#include <QStackedWidget>

#include "gui/hello_gui.h"
#include "gui/preparation.h"
#include "rclcpp/rclcpp.hpp"
#include "rviz_common/ros_integration/ros_node_abstraction.hpp"
#include <rviz_common/display_group.hpp>


int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    QApplication app(argc, argv);

    auto node_shared_ptr = std::make_shared<rviz_common::ros_integration::RosNodeAbstraction>("gui_test");
    auto node_weak_ptr = std::weak_ptr<rviz_common::ros_integration::RosNodeAbstractionIface>(node_shared_ptr);
    // Create the stacked widget and pages
    auto shared_rviz_panel = std::make_shared<RvizPanel>(&app);
    QWidget* shared_rviz_widget = shared_rviz_panel->initializeWidget(node_weak_ptr);


    QStackedWidget *stack = new QStackedWidget();

    auto hello_gui = new HelloGui(&app, node_weak_ptr, shared_rviz_widget, shared_rviz_panel);
    auto second_window = new Form(&app, node_weak_ptr, shared_rviz_widget);
    auto execute_page = new FormHau(&app, node_weak_ptr, shared_rviz_widget);

    stack->addWidget(hello_gui);  
    stack->addWidget(second_window);  // Page 1
    // Page 0
    stack->addWidget(execute_page);  // Page 2

    QObject::connect(hello_gui, &HelloGui::switchToSecondWindow, stack, [stack]() {
        stack->setCurrentIndex(1);
    });
    QObject::connect(hello_gui, &HelloGui::switchToExecutePage, stack, [stack]() {
        stack->setCurrentIndex(2);
    });

    QObject::connect(second_window, &Form::backToMainWindow, stack, [stack]() {
        stack->setCurrentIndex(0);
    });
    QObject::connect(execute_page, &FormHau::backToMainWindow, stack, [stack]() {
        stack->setCurrentIndex(0);
    });

    int flag = 0;
    int last_window_index = 0;
    rviz_common::Display * robot_model_display_ = nullptr;
    QObject::connect(stack, &QStackedWidget::currentChanged, [hello_gui, second_window,execute_page, shared_rviz_widget, shared_rviz_panel, &flag, &robot_model_display_,&last_window_index](int index) {
        qDebug() << "Current index:" << index;
        auto manager = shared_rviz_panel->getManager();
        // if(flag == 0){
        //     robot_model_display_ = manager->createDisplay("rviz_default_plugins/RobotModel", "Robot Model", true);
        //     flag = 1;
        // }
        if(index == 1){
            hello_gui->closeRviz();
            second_window->openRviz(shared_rviz_widget);
            if (manager) {
                // manager->setFixedFrame("zivid_optical_frame");
                manager->setFixedFrame("base_link");
                    // if (!robot_model_display_) {
                    //     throw std::runtime_error("Error creating RobotModel display");
                    // }
                    robot_model_display_ = manager->createDisplay("rviz_default_plugins/RobotModel", "Robot Model", true);
                    robot_model_display_->subProp("Description Topic")->setValue("robot_description");
                    robot_model_display_->subProp("Description Source")->setValue("Topic");

                    robot_model_display_->subProp("Visual Enabled")->setValue(true);
                    robot_model_display_->subProp("Collision Enabled")->setValue(false);
                    robot_model_display_->subProp("Update Interval")->setValue(0.0);  // 0 for continuous
            }
        }
        else if(index == 0){
            if(last_window_index == 1){
                second_window->closeRviz();
            } else if(last_window_index == 2){
                execute_page->closeRviz();
            }
            hello_gui->openRviz(shared_rviz_widget);
            if (manager) {
                manager->setFixedFrame("zivid_optical_frame");
                robot_model_display_->subProp("Visual Enabled")->setValue(false);
                robot_model_display_->subProp("Collision Enabled")->setValue(false);
                robot_model_display_->subProp("Update Interval")->setValue(0.0);

            }
        }

        else if(index == 2){
            if(last_window_index == 0){
                hello_gui->closeRviz();
            }
            else if(last_window_index == 1){
                second_window->closeRviz();
            }
            // second_window->closeRviz();
            // hello_gui->closeRviz();
            execute_page->openRviz(shared_rviz_widget);
            if (manager) {
                // manager->setFixedFrame("zivid_optical_frame");
                manager->setFixedFrame("base_link");
                    // if (!robot_model_display_) {
                    //     throw std::runtime_error("Error creating RobotModel display");
                    // }
                    robot_model_display_ = manager->createDisplay("rviz_default_plugins/RobotModel", "Robot Model", true);
                    robot_model_display_->subProp("Description Topic")->setValue("robot_description");
                    robot_model_display_->subProp("Description Source")->setValue("Topic");

                    robot_model_display_->subProp("Visual Enabled")->setValue(true);
                    robot_model_display_->subProp("Collision Enabled")->setValue(false);
                    robot_model_display_->subProp("Update Interval")->setValue(0.0);  // 0 for continuous
            }
            // if (manager) {
            //     manager->setFixedFrame("zivid_optical_frame");
            //     robot_model_display_->subProp("Visual Enabled")->setValue(false);
            //     robot_model_display_->subProp("Collision Enabled")->setValue(false);
            //     robot_model_display_->subProp("Update Interval")->setValue(0.0);
            // }
        }
        last_window_index = index;
        manager->startUpdate();
    });

    stack->setWindowTitle("Stacked Window Example");
    stack->resize(1850, 1000);
    stack->show();

    return app.exec();
}
